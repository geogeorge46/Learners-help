# Learner's licence question bank

- `questions.json` – 877 questions (UTF-8, Malayalam). Fields: id, number (number printed in the PDF; 660 appears twice), question, question_image, options[{key,text,image}], answer (A-D), answer_text, explanation / explanation_image / subject / topic (empty, for you to fill), page (PDF page).
- `images/` – WebP files. `q0001.webp` = picture belonging to the question; `q0342_A.webp` … `_D.webp` = picture options (those questions have `text: null` on each option).
- Images are clean: the PDF's green answer glow and red watermark were removed.
